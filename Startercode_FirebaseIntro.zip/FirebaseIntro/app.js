db.collection('/restaurants/HlhXtpu1m51q4oZxAQHG/reviews').get().then(data => {
    console.log(data.docs);
})